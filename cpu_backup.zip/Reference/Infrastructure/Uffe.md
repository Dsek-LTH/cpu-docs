# Uffe

Datorn i styrelserummet. Kör [Deethoven]() på CentOS Stream 8/9.