# Uffe

Datorn i styrelserummet. Kör [D-thoven](https://cpu.dsek.se./../Services/Dethoven.md) på CentOS Stream 8/9.