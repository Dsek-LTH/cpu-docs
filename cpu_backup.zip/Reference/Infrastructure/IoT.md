# IoT

Lists other computers and infrastructure that is used

IoT devices don't use freeipa login. All devices except JuliasiPhone4s have the same login, stored in [syspass](https://cpu.dsek.se./../Services/Syspass.md). Search "iot".