# Boss

LED matrix display located on the bar, facing iDét. Powered by a Raspberry Pi which displays videos. Pronounced "bus".

OS is Raspian. Login information found in [Syspass](https://cpu.dsek.se./../../Services/Syspass.md) under "IoT pis".

Controller and configuration are pulled from <https://github.com/Dsek-LTH/boss/>. Videos are automatically pulled from [https://github.com/Dsek-LTH/boss_vidoes/](https://github.com/Dsek-LTH/boss_videos)