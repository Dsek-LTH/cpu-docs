# RootNet/JuliasiPhone4S

`RootNet` is our secret Wi-Fi network in iDét. It's used by some of our IoT devices.

JuliasiPhone4S is the name of the Wi-Fi access point serving `RootNet`. It's a Ubiquiti unifi AC Lite. You'll find it in the ceiling outside Caféförrådet. The management interface, Unifi Controller, runs on [hyacinth](https://cpu.dsek.se./../Blossom/Hyacinth.md), files in `/opt/UniFi`. The password is lost to history.