# Screendump

Three screens mounted over DCafé, named `screendump0`, `screendump1` and `screendump2`. They run [casta](https://github.com/dsek-LTH/asta), the client app for our [asta](https://cpu.dsek.se./../../Services/Asta.md) screen management system.

OS is Raspian. Login information found in [Syspass](https://cpu.dsek.se./../../Services/Syspass.md) under "IoT pis".