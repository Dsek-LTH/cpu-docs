# Sparky

Arcade machine located in the corner of iDét, by the outside exit.