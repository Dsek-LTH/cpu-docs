# Pine

TV located in the corner of the bar, beside [Boss](./Boss.md). Connected to a Raspberry Pi which is connected to [Asta](./../../Services/Asta.md). Most of the time, it shows the binary clock [Basta](https://github.com/stagrim/basta). Plays sound at various times during the day using cronjobs.

OS is Raspian. Login information found in [Syspass](https://cpu.dsek.se./../../Services/Syspass.md) under "IoT pis".