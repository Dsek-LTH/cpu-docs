# Cone

TV located in the far corner of iDét, by the sofas. Connected to a Raspberry Pi which is connected to [Asta](./../../Services/Asta.md). Most of the time, it shows a rolling schedule of Lofi girl and the guild calendar.