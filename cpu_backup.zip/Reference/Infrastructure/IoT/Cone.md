# Cone

A raspberry pi connected to theTV located in the far corner of iDét, by the sofas. Most of the time, it shows a rolling schedule of Lofi girl and the guild calendar.

OS is Raspian. Login information found in [Syspass](https://cpu.dsek.se./../../Services/Syspass.md) under "IoT pis".

## Services

* [Asta](https://cpu.dsek.se./../../Services/Asta.md) client. 
* acorn-unmute: the signifier button which toggles sound on/off.
* nuke: connected to a sensor on the door and a siren that sounds when the door is opened during a pub. Currently disabled due to complaints.