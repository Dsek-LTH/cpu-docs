# Hyacinth

Agerar som router. Kör även Ubiquiti unifi controller.