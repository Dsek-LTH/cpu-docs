# Registreringssidan

| **🌐 URL** | <https://regnew.dsek.se/> |
|----|----|
| **💡 Purpose** | Registreringsportal för nya användare |
| **👥 Stakeholders** | Sektionens medlemmar |
| **🏗️ Infrastructure** | gatekeeper.blossom |
| **🔗 Dependencies** | !!connected software!! |
| **🚦 Status** | active |
| **⚠️ Criticality** | high |
| **🗃️ Source** | [Steindt/account](https://github.com/Steindt/account) |

```bash
/home/_reg_email/
```