# Dimman

| **🌐 URL** | [https://dimman.blossom.dsek.se](https://dimman.blossom.dsek.se/) |
|----|----|
| **💡 Purpose** | Central hantering av våra virtuella maskiner |
| **👥 Stakeholders** | CPU |
| **🏗️ Infrastructure** | [lavender.blossom](https://cpu.dsek.se./../Infrastructure/Blossom/Lavender.md), primrose och amaranth |
| **🔗 Dependencies** | none |
| **🚦 Status** | maintenance |
| **⚠️ Criticality** | high |
| **🗃️ Source** | <https://www.ovirt.org/download/> |


See [oVirt guide](./../../Guides/Virtualisering/oVirt.md) for more details.