# Papercut

| **🌐 URL** | <https://print.dsek.se/> |
|----|----|
| **💡 Purpose** | Utskrifter på skrivaren i styrelserummet |
| **👥 Stakeholders** | Sektionens funktionärer |
| **🏗️ Infrastructure** | [uffe](./../Infrastructure/Uffe.md) |
| **🔗 Dependencies** | !!connected software!! |
| **🚦 Status** | inactive (broken) |
|  **⚠️ Criticality** | medium |
| **🗃️ Source** | !!repo!! |