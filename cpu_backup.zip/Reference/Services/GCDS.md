# GCDS

| **🌐 URL** | N/A |
|----|----|
| **💡 Purpose** | Google Cloud Directory Sync — synkar användare och grupper med google |
| **👥 Stakeholders** | Sektionens medlemmar |
| **🏗️ Infrastructure** | docker.[lavender.blossom](./../Infrastructure/Blossom/Lavender.md) |
| **🔗 Dependencies** | [FreeIPA](./FreeIPA.md) |
| **🚦 Status** | active |
| **⚠️ Criticality** | high |
| **🗃️ Source** | !!repo!! |