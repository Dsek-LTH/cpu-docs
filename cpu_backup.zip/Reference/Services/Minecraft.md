# Minecraft

| **🌐 URL** | minecraft.dsek.se |
|----|----|
| **💡 Purpose** | Minecraftserver |
| **👥 Stakeholders** | Sektionens medlemmar |
| **🏗️ Infrastructure** | [magnolia](https://cpu.dsek.se./../Infrastructure/Blossom/Magnolia.md).blossom |
| **🔗 Dependencies** | [Whitelist](https://cpu.dsek.se./Whitelist.md) |
| **🚦 Status** | active |
| **⚠️ Criticality** | low |
| **🗃️ Source** | !!repo!! |


Consists of a survival server running as a systemd service. Further information is located in /srv/README.md on magnolia.blossom. Commands are run through rcon.