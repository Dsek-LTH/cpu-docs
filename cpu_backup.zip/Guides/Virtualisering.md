# Virtualisering

Sektionen har ett eget virtualiseringskluster (i folkmun kallat dimman).