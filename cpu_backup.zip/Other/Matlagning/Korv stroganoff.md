# Korv stroganoff

* <https://www.arla.se/recept/korv-stroganoff/>
* 2-3 st falukorv
* 2-3 kg ris
* Vegokorv (vegansk pref)
* 1 l havregrädde (vegansk+mjölkfri pref)
* 5 gul lök
* 1 tomatpuré