# 🍝 Matlagning

### Info :information_source:

* Budget 250 kr
* [Matpreferenser](https://docs.google.com/spreadsheets/d/1L_H8zk-Cp051SVphuGOeXcIg7jxB8sV7A66cGiwjBy0/edit?usp=sharing)

### Maträtter :knife_fork_plate:

* Pasta med köttbullar
* Pasta med pastasås och röda linser
* Pasta arrabiata
* Spaghetti carbonara
* Spaghetti och köttfärssås
* [Korv stroganoff](./Matlagning/Korv%20stroganoff.md)
* [Fler billiga recept](https://www.arla.se/recept/samling/billig-middag/)

### Team :busts_in_silhouette:

| **(13)** | 🧑‍🍳 | 🧑‍🍳 | 🧑‍🍳 |
|----|----|----|----|
| 3 feb | Daniel | David |    |
| 10 feb | Esbjörn | Felix | Simon |
| 17 feb | Joel | Tomas | Albin |
| 24 feb | Adam | Julius | Oliver |
| 3 mars | Hampus | Anahita | Rufus |
| 10 mars | Ludvig | Manfred | Melker |
| 24 mars | Anton | Anahita | Isak |
| 7 april | Scott? | Oscar? | Erik? |
| 14 april | Dag? | Loke? | Christofer? |
| 5 maj |    |    |    |
| 12 maj |    |    |    |
| 19 maj |    |    |    |
| 26 maj |    |    |    |

| **(10)** | 🧑‍🍳 | 🧑‍🍳 | 🧑‍🍳 |
|----|----|----|----|
| 6 okt |    |    |    |
| 13 okt |    |    |    |
| 20 okt |    |    |    |
| 3 nov |    |    |    |
| 10 nov |    |    |    |
| 17 nov |    |    |    |
| 24 nov |    |    |    |
| 1 dec |    |    |    |
| 8 dec |    |    |    |
| 15 dec |    |    |    |