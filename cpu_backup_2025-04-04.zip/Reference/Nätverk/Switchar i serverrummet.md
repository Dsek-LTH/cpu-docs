# Switchar i serverrummet

Jag menar racket, men det fattar du nog.

## Enheter

* Ratchet (Cisco 2960X Series, 24 portar)\nVår enhet som sköter kopplingarna till våra blommnoder samt Kit och Rivet.
* Clank (Cisco 2960X Series, 24 portar)\nClank sköter filöverföring till Pando, vår filserver. Den har kopplingar till alla blommor men inte utåt
* Rivet (Cisco 2960X Series, 24 portar)\nRivet sköter kopplingar till Geekend
* Kit (Cisco 2960X Series, 48 portar PoE)\nKit håller alla kopplingar till PoE devices.

Mer information återfinns på nätverkssidan