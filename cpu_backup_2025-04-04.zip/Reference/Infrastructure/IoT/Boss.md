# Boss

LED matrix display located on the bar, facing iDét. Powered by a Raspberry Pi which displays videos. Pronounced "bus".

Controller, configuration and videos are pulled from <https://github.com/Dsek-LTH/boss/>