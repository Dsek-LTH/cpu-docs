# Pando

File server for all VMs running on oVirt.

OS: CentOS Stream 8

Disks are mounted as following:

* /klusterbitar - 16Tb
* /save-me-something-died - 32Tb
* /turbo_the_snail - 8Tb
* / - 500Gb