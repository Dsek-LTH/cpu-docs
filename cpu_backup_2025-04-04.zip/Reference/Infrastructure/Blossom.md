# Blossom

September 2018 donerades 8st noder ifrån Lunarc till Rootmästeriet. Dessa är tänkta att vara servrar för alla våra tjänster.

De övre 4 med 64GB RAM och 2st 250GB hårddiskar. De nedre 4 har 120GM RAM och lite olika mängder lagring.

## Mjukvara/Konfigruation

De fyra övre maskinerna kör CentOS-7. Konfas med en Anisble playbook, se repo <https://github.com/Dsek-LTH/blossom>.

Tre av de undre kör OKD-klustret och den fjärde har Fedora 41 installerat.