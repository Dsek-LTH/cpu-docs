# gerDa

| **🌐 URL** | <https://gerda.dsek.se/> |
|----|----|
| **💡 Purpose** | Skapa dokument med D-sektionens LaTeX-mallar |
| **👥 Stakeholders** | Sektionens medlemmar |
| **🏗️ Infrastructure** | motion-generator.blossom |
| **🔗 Dependencies** | none |
| **🚦 Status** | active |
| **⚠️ Criticality** | medium |
| **🗃️ Source** | [alfredgrip/gerDa](https://github.com/alfredgrip/gerDa) |