# Deethoven

| **🌐 URL** | <https://music.dsek.se/> |
|----|----|
| **💡 Purpose** | Spela musik i iDét |
| **👥 Stakeholders** | Sektionens funktionärer |
| **🏗️ Infrastructure** | [uffe](./../Infrastructure/Uffe.md) |
| **🔗 Dependencies** | [Keycloak](./Keycloak.md) |
| **🚦 Status** | !!active/maintenance/deprecated!! |
| **⚠️ Criticality** | low |
| **🗃️ Source** | [Steindt/musicserver](https://github.com/Steindt/musicserver) |