# FreeIPA

| **🌐 URL** | <https://ipa.dsek.se/> |
|----|----|
| **💡 Purpose** | Centralized user and access management through LDAP |
| **👥 Stakeholders** | CPU |
| **🏗️ Infrastructure** | gatekeeper.blossom |
| **🔗 Dependencies** | none |
| **🚦 Status** | active |
| **⚠️ Criticality** | high |
| **🗃️ Source** | [freeipa.org/page/Downloads](https://www.freeipa.org/page/Downloads) |