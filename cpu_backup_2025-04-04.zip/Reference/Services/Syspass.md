# Syspass

| **🌐 URL** | <https://pass.dsek.se/> |
|----|----|
| **💡 Purpose** | Password manager |
| **👥 Stakeholders** | CPU |
| **🏗️ Infrastructure** | valvet.blossom |
| **🔗 Dependencies** | [FreeIPA](./FreeIPA.md) |
| **🚦 Status** | deprecated — to be replaced by Vaultwarden |
| **⚠️ Criticality** | medium |
| **🗃️ Source** | <https://hub.docker.com/r/syspass/syspass> |