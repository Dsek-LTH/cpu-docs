# Shlink

| **🌐 URL** | <https://shlink.dsek.se/> ([https://link.dsek.se/](https://shlink.dsek.se/)) |
|----|----|
| **💡 Purpose** | Link shortener |
| **👥 Stakeholders** | Sektionens funktionärer |
| **🏗️ Infrastructure** | [OKD](https://cpu.dsek.se./../../Explanation/OKD.md) |
| **🔗 Dependencies** | none |
| **🚦 Status** | active |
| **⚠️ Criticality** | medium |
| **🗃️ Source** | <https://hub.docker.com/r/shlinkio/shlink> |