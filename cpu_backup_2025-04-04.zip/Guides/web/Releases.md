# Releases

# How to publish a new release


1. Go to the [releases page](https://github.com/Dsek-LTH/web/releases) in the repo.
2. Click "Draft a new release".
3. Create a tag with the format `YY.MM.DDmicro`, e.g `24.11.26b` for a second release on 2024-11-26.
4. Click "Generate release notes".
5. Click "Publish release".